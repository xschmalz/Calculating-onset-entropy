#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul  4 11:49:09 2018

@author: Xenia
"""

# Packages
import pandas as pd
import math

# Reading in lists with spellings (Orth.txt) and pronunciations (Phon.txt)
with open("/Users/Xenia/Documents/DRC_Across_Langs/GPC_Extraction/Orth.txt") as file:
    lines = [line.strip() for line in file]
Orth = lines
with open("/Users/Xenia/Documents/DRC_Across_Langs/GPC_Extraction/Phon.txt") as file:
    lines = [line.strip() for line in file]
Phon = lines

# Sample list of words' orthography and phonology
#Orth = ["cat","dog","chat","doc","chad","pet","get","gap","clap","lap","was","gas","cent","kate"]
#Phon = ["k3t","dQg","C3t","dQc","C3d","pet","get","g3p","kl3p","l3p","wQz","g3s","sent","kAt"]

# List of first letters and first phonemes
Letter = []
for i in range(len(Orth)):
    Letter.append(Orth[i][0])
Phoneme = []
for i in range(len(Phon)):
    Phoneme.append(Phon[i][0])
    
# Calculating the phoneme frequency (freqPhon) and the PGC frequency (freqPGC) for each PGC
df = pd.DataFrame()

df["Phoneme"] = Phoneme 
df["Letter"] = Letter

df["freqPhon"] = df.groupby("Phoneme").transform('count')
df["freqPGC"] = df.groupby(["Letter","Phoneme"]).transform('count')
df.drop_duplicates(subset = ("Phoneme", "Letter"), inplace=True )
print(df)
print(type(df))

# Now a loop to calculate onset entropy for each PGC
H = []
s = 0
for index, row in df.iterrows():
    s = df["freqPGC"][index]/df["freqPhon"][index] *(math.log((df["freqPGC"][index]/df["freqPhon"][index]),2))
    print(s)
    H.append(s)
print(H) # The onset entropy for each PGC
df["H"] = H     
print(df)


# Now, calculating the entropy for each phoneme
#df2 = df.groupby("Phoneme").transform('count')
df2 = df.groupby(df["Phoneme"],as_index=False).sum()
print(df2)

Entropy = df2["H"].mean()
Entropy = Entropy * -1
print(Entropy)